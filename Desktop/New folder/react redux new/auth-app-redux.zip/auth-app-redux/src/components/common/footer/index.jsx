import './style.scss';
const Footer = () => {
    return (
        <div className='footer-wrap p-4'>
            Copyright © e-cart website
           
        </div>

    );
};

export default Footer;