import React from 'react';

const ChatScreen = () => {
    return (
        <div>
            <h1>chat</h1>
        </div>
    );
};

export default ChatScreen;