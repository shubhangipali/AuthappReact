export const SliderData = [
    {
        image: require('../../assets/slider/Biryani_2.png'),
    },
    {
        image: require('../../assets/slider/Burger.png'),
    },
    {
        image: require('../../assets/slider/Cakes.png'),
    },
    {
        image: require('../../assets/slider/Chinese.png'),
    },
    {
        image: require('../../assets/slider/Chole_Bature.png'),
    },
    {
        image: require('../../assets/slider/Dosa.png'),
    },
    {
        image: require('../../assets/slider/Idli.png'),
    },
    {
        image: require('../../assets/slider/Khichdi.png'),
    },
    {
        image: require('../../assets/slider/Noodles.png'),
    },
    {
        image: require('../../assets/slider/North_Indian_4.png'),
    },
    {
        image: require('../../assets/slider/Paratha.png'),
    },
    {
        image: require('../../assets/slider/Pasta.png'),
    },
    {
        image: require('../../assets/slider/Pav_Bhaji.png'),
    },
    {
        image: require('../../assets/slider/Pizza.png'),
    },
    {
        image: require('../../assets/slider/Poori.png'),
    },
    {
        image: require('../../assets/slider/Pure_Veg.png'),
    },
    {
        image: require('../../assets/slider/Rolls.png'),
    },
    {
        image: require('../../assets/slider/Shakes.png'),
    },
    {
        image: require('../../assets/slider/Shawarma.png'),
    },
    {
        image: require('../../assets/slider/South_Indian_4.png'),
    },
];